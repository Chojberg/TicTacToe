
import java.util.Scanner;

/**
 * @author Chanelle Hojberg
 * 
 * 
 */

/**
 * This class is a console program that plays Tic Tac Toe with the user
 * and competes with the Computer AI
 */

public class TicTacToe {
	
	
	public int player_turn = 1;
	public int computer_turn = 2;
	public int turn = 0;
	public String sign;
	int player_counter = 0;
	
	/**
	 * The default constructor takes in a 2D String array that holds the 
	 * coordinates of the matrix and represents each coordinate with a dot
	 * @param matrix_game is a 2D array of Strings 
	 */
	public TicTacToe(String[][] matrix_game)
	{
		for (int row = 0; row < 3; ++row)
		{
			for (int col = 0; col < 3; ++col)
			{
				matrix_game[row][col] = "___ ";	
			}
		}
	}
	
	/**
	 * The printBoard() method displays the board in a formatted structure
	 * @param matrix_game is a 2D array of Strings that is the matrix 
	 */
	public void printBoard(String[][] matrix_game)
	{
		int counter = 1;
		System.out.printf("   C1 \t  C2\t  C3   \t\n");
		for (int row = 0; row < 3; ++row)
		{
			System.out.printf("R%d", counter);
			for (int col = 0; col < 3; ++col)
			{
				System.out.printf("  %s\t", matrix_game[row][col]);	
			}
			System.out.println();
			counter++;
		}
		System.out.println();
	}
	
	/**
	 * The checkTurn() method checks if the user would like to make the first move or not
	 * and based on the user input it gives the turn to the player or the computer
	 * @return an integer which represents the player's or computer's turn
	 */
	public int checkTurn()
	{
		System.out.println("Would you like to make the first move? (yes[1] or no[0]) ");
		Scanner s = new Scanner(System.in);
		int valid_input = validFirstMoveInput(s);
		{
			if (valid_input == 1)
			{
				turn = player_turn;
			}
			else
			{
				turn = computer_turn;
			}
			return turn;
		}
	}
	
	/**
	 * The returnSign() method returns the string "X" or "O" based on whose turn it is
	 * @return a String which is either an "X" or "O"
	 */
	public String returnSign()
	{
		if (turn == player_turn)
		{
			sign = "X";
		}
		else
		{
			sign = "O";
		}
		return sign;
	}
	
	/**
	 * The validRowCol() method checks if the specified row and col are valid moves
	 * in the matrix, meaning that the spot should be empty
	 * @param matrix_game is a 2D array of strings that represents the matrix
	 * @param row is an integer that represents a row in the matrix
	 * @param col is an integer that represents a column in the matrix
	 * @return boolean which tells if the row and col was a valid move or not
	 */
	public boolean validRowCol(String[][] matrix_game, int row, int col)
	{
		String x = new String("X");
		String o = new String("O");
		String m = matrix_game[row-1][col-1];
		if (m.equals(x) || m.equals(o)) //if there is already an X or O there, then it is not an valid input
		{
			return false;
		}
		return true;
	}
	
	/**
	 * The isBoardEmpty() method checks if all of the spots are empty in the matrix
	 * @param matrix_game is a 2D array of strings which is the matrix
	 * @return boolean that represents if the entire board is empty or not
	 */
	public boolean isBoardEmpty(String[][] matrix_game)
	{
		for (int row = 0; row < 3; ++row)
		{
			for (int col = 0; col < 3; ++col)
			{
				if (!matrix_game[row][col].equals(". "))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * The isBoardFull() method checks if the entire board is occupied with X's and O's
	 * @param matrix_game is a 2D array of strings that represents the matrix
	 * @return boolean that tells if the entire board is full or not
	 */
	public boolean isBoardFull(String[][] matrix_game)
	{
		for (int row = 0; row < 3; ++row)
		{
			for (int col = 0; col < 3; ++col)
			{
				if (matrix_game[row][col].equals(". "))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * The emptySpot() method checks if a spot is empty and returns an array 
	 * with the coordinate values and a boolean that tells if that spot is empty or not
	 * @param matrix_game is a 2D array of strings that represents the matrix
	 * @param row is an integer
	 * @param col is an integer
	 * @return an array of integers in which the first two values are the coordinates and the
	 * third value is true or false 
	 */
	public int[] emptySpot(String[][] matrix_game, int row, int col)
	{
		int t = 1;
		int f = 0;
		if (matrix_game[row][col].equals(". "))
		{
			return new int[] {row, col, t};
		}
		return new int[] {-1,-1, f};
	}
	
	/**
	 * The check4CornersEmpty() method checks if the 4 corners are empty spots 
	 * @param matrix_game is a 2D array of strings
	 * @return an array of 2 integers which holds the empty coordinate in the 4 spots
	 */
	private int[] check4CornersEmpty(String[][] matrix_game)
	{
		int i = emptySpot(matrix_game, 0, 0)[2];
		int j = emptySpot(matrix_game, 0, 2)[2];
		int k = emptySpot(matrix_game, 2, 0)[2];
		int l = emptySpot(matrix_game, 2, 2)[2];
		
		int coordinate_r = 0;
		int coordinate_c = 0;
		
		if (i == 1)
		{
			coordinate_r = emptySpot(matrix_game, 0, 0)[0];
			coordinate_c = emptySpot(matrix_game, 0, 0)[1];
		}
		else if (j == 1)
		{
			coordinate_r = emptySpot(matrix_game, 0, 2)[0];
			coordinate_c = emptySpot(matrix_game, 0, 2)[1];
		}
		else if (k == 1)
		{
			coordinate_r = emptySpot(matrix_game, 2, 0)[0];
			coordinate_c = emptySpot(matrix_game, 2, 0)[1];
		}
		else if (l == 1)
		{
			coordinate_r = emptySpot(matrix_game, 2, 2)[0];
			coordinate_c = emptySpot(matrix_game, 2, 2)[1];
		}
		return new int[] {coordinate_r, coordinate_c};
		
	}
	
	/**
	 * The check4DiamondSpots() method checks if the top middle, middle leftmost, 
	 * middle rightmost, middle bottom are empty spots or not
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @return an array of 2 integers that holds the coordinate of one of the 4 spots if it 
	 * is empty
	 */
	private int[] check4DiamondSpots(String[][] matrix_game)
	{
		int i = emptySpot(matrix_game, 0, 1)[2];
		int j = emptySpot(matrix_game, 1, 0)[2];
		int k = emptySpot(matrix_game, 1, 2)[2];
		int l = emptySpot(matrix_game, 2, 1)[2];
		
		int coordinate_r = 0;
		int coordinate_c = 0;
		
		if (i == 1)
		{
			coordinate_r = emptySpot(matrix_game, 0, 1)[0];
			coordinate_c = emptySpot(matrix_game, 0, 1)[1];
		}
		else if (j == 1)
		{
			coordinate_r = emptySpot(matrix_game, 1, 0)[0];
			coordinate_c = emptySpot(matrix_game, 1, 0)[1];
		}
		else if (k == 1)
		{
			coordinate_r = emptySpot(matrix_game, 1, 2)[0];
			coordinate_c = emptySpot(matrix_game, 1, 2)[1];
		}
		else if (l == 1)
		{
			coordinate_r = emptySpot(matrix_game, 2, 1)[0];
			coordinate_c = emptySpot(matrix_game, 2, 1)[1];
		}
		
		return new int[] {coordinate_r, coordinate_c};
		
	}
	
	/**
	 * The defendLeftDiag() method creates a counter of how many "X"'s there are in the left
	 * diagonal and saves the coordinate of the one that is empty
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @return an array of 2 values that holds the counter and the 
	 * coordinate of the empty spot in the left diagonal
	 */
	private int[] defendLeftDiag(String[][] matrix_game)
	{
		int left_diag_count = 0;
		int save_left = 0;
		for (int left_counter = 0; left_counter < 3; ++left_counter)
		{
			if ((matrix_game[left_counter][left_counter].equals("X")))
			{
				++left_diag_count;
			}
			else
			{
				save_left = left_counter;
			}
		}
		return new int[] {left_diag_count, save_left};
	}
	
	/**
	 * The defendRightDiag() method creates a counter of how many "X"'s there are in the right
	 * diagonal and saves the coordinate of the one that is empty
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @return an array of 3 values that holds the counter and
	 * the coordinate (row and column) of the empty spot in the right diagonal
	 */
	private int[] defendRightDiag(String[][] matrix_game)
	{
		int right_diag_count = 0;
		int save_right1 = 0;
		int save_right2 = 0;
		for (int inc_counter = 0, dec_counter = 2 ; inc_counter < 3 && dec_counter >= 0; ++inc_counter, --dec_counter)
		{
			if ((matrix_game[inc_counter][dec_counter].equals("X")))
			{
				++right_diag_count;
			}
			else
			{
				save_right1 = inc_counter;
				save_right2 = dec_counter;
			}
		}
		return new int[] {right_diag_count, save_right1, save_right2};
	}
	
	/**
	 * The defendHorizontal() method creates a counter of how many "X"'s there are in the 3 
	 * horizontal lanes and saves the coordinate of the one that is empty in each lane
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param row is an integer that represents the x coordinate of each horizontal lane
	 * @return an array of 3 values that holds the counter and the coordinate(row and column)
	 * of the empty spot in each of the horizontal lanes
	 */
	private int[] defendHorizontal(String[][] matrix_game, int row)
	{
		int horizontal_count1 = 0;
		int sh1 = 0;
		int sh2 = 0;
		for (int col = 0; col < 3; ++col)
		{
			if (matrix_game[row][col].equals("X"))
			{
				++horizontal_count1;
			}
			else 
			{
				sh1 = row;
				sh2 = col;
			}
		}
		return new int[] {horizontal_count1, sh1, sh2};
	}
	
	/**
	 * The defendVertical() method creates a counter of how many "X"'s there are in the 3 
	 * vertical lanes and saves the coordinate of the one that is empty in each lane
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param col is an integer that represents the y coordinate of each vertical lane
	 * @return an array of 3 values that holds the counter and the coordinate(row and column)
	 * of the empty spot in each of the vertical lanes
	 */
	private int[] defendVertical(String[][] matrix_game, int col)
	{
		int vertical_count = 0;
		int sv1 = 0;
		int sv2 = 0;
		for (int row = 0; row < 3; ++row)
		{
			if (matrix_game[row][col].equals("X"))
			{
				++vertical_count;
			}
			else
			{
				sv1 = row;
				sv2 = col;
			}
		}
		return new int[] {vertical_count, sv1, sv2};
	}
	
	/**
	 * The defendMoves() method checks if it can find a spot that it can defend in any of the 8 directions,
	 * meaning that if it can block the player from winning
	 * @param matrix_game is a 2D array of string that is the matrix
	 * @return an array of 2 integers that represents the coordinate of the defending move
	 */
	public int[] defendMoves(String[][] matrix_game)
	{
		int a = defendLeftDiag(matrix_game)[0];
		int b = defendRightDiag(matrix_game)[0];
		int c = defendHorizontal(matrix_game, 0)[0];
		int e = defendHorizontal(matrix_game, 1)[0];
		int f = defendHorizontal(matrix_game, 2)[0];
		int d = defendVertical(matrix_game, 0)[0];
		int g = defendVertical(matrix_game, 1)[0];
		int h = defendVertical(matrix_game, 2)[0];
		int coordinate_r = 0;
		int coordinate_c = 0;
		
		if ((a == 2) || (b == 2) || (c==2) || (e==2) || (f==2) || (d==2) || (g==2) || (h==2))
		{
			if ((a==2) && ((emptySpot(matrix_game, defendLeftDiag(matrix_game)[1], defendLeftDiag(matrix_game)[1]))[2] == 1))
			{
				coordinate_r = defendLeftDiag(matrix_game)[1];
				coordinate_c = defendLeftDiag(matrix_game)[1];
			}
			if ((b==2)  && ((emptySpot(matrix_game, defendRightDiag(matrix_game)[1], defendRightDiag(matrix_game)[2]))[2] == 1))
			{
				coordinate_r = defendRightDiag(matrix_game)[1];
				coordinate_c = defendRightDiag(matrix_game)[2];
			}
			if ((c==2) && ((emptySpot(matrix_game, defendHorizontal(matrix_game, 0)[1], defendHorizontal(matrix_game, 0)[2]))[2] == 1))
			{
				coordinate_r = defendHorizontal(matrix_game, 0)[1];
				coordinate_c = defendHorizontal(matrix_game, 0)[2];
				//System.out.println("Testing horizontal" + " "+ (coordinate_r+1) + (coordinate_c+1));
			}
			if ((e==2) && ((emptySpot(matrix_game, defendHorizontal(matrix_game, 1)[1], defendHorizontal(matrix_game, 1)[2]))[2] == 1))
			{
				coordinate_r = defendHorizontal(matrix_game, 1)[1];
				coordinate_c = defendHorizontal(matrix_game, 1)[2];
			}
			if ((f==2) && ((emptySpot(matrix_game, defendHorizontal(matrix_game, 2)[1], defendHorizontal(matrix_game, 2)[2]))[2] == 1))
			{
				coordinate_r = defendHorizontal(matrix_game, 2)[1];
				coordinate_c = defendHorizontal(matrix_game, 2)[2];
			}
			if ((d==2) && ((emptySpot(matrix_game, defendVertical(matrix_game, 0)[1],  defendVertical(matrix_game, 0)[2]))[2] == 1))
			{
				coordinate_r = defendVertical(matrix_game, 0)[1];
				coordinate_c = defendVertical(matrix_game, 0)[2];
				//System.out.println("Testing vertical "+ (coordinate_r+1) + (coordinate_c+1));
			}
			if ((g==2) && ((emptySpot(matrix_game, defendVertical(matrix_game, 1)[1],  defendVertical(matrix_game, 1)[2]))[2] == 1))
			{
				coordinate_r = defendVertical(matrix_game, 1)[1];
				coordinate_c = defendVertical(matrix_game, 1)[2];
			}
			if ((h==2) && ((emptySpot(matrix_game, defendVertical(matrix_game, 2)[1],  defendVertical(matrix_game, 2)[2]))[2] == 1))
			{
				coordinate_r = defendVertical(matrix_game, 2)[1];
				coordinate_c = defendVertical(matrix_game, 2)[2];
			}
			if (emptySpot(matrix_game, coordinate_r, coordinate_c)[2] == 1)
			{
				
				return new int[] {1, coordinate_r, coordinate_c};		
			}
			else
			{
				return new int[] {0,-1,-1};
			}
			
		}
		else
		{
			return new int[] {0,-1,-1};
		}	
		
	}
	
	/**
	 * The computerPlays() method makes its AI move by determining if it needs to
	 * defend or place a move based on the priority levels
	 * @param matrix_game is a 2D array of strings
	 */
	public void computerPlays(String[][] matrix_game)
	{
		int counter = 0;
		turn = computer_turn;
		if (isBoardEmpty(matrix_game)) //first move
		{
			System.out.println("Computer's move was: 2,2");
			matrix_game[1][1] = returnSign();
		}
		if (!matrix_game[1][1].equals("X")) //place the first priority
		{
			System.out.println("Computer's move was: 2,2");
			if (counter == 0)
			{
				System.out.println("A");
				matrix_game[1][1] = returnSign();
				
			}
			if (counter == 1)
			{
				System.out.println("B");
				callingAll4SpotsChecker(matrix_game);	
			}
			++counter;
		}
		
		if ((matrix_game[1][1].equals("X")) || ((player_counter >= 2) && (!isBoardEmpty(matrix_game)) && (!matrix_game[1][1].equals(". "))))
		{
			System.out.println("C");
			callingAll4SpotsChecker(matrix_game);
		}
		
		printBoard(matrix_game);
		
	}
	
	/**
	 * The callingAll4SpotsChecker() method defends and checks the 4 corners and 4 diamond spots in the matrix, 
	 * basically it is the AI that handles all the checking and prioritizing
	 * @param matrix_game is a 2D array of strings that is the matrix
	 */
	public void callingAll4SpotsChecker(String[][] matrix_game)
	{
		int i = emptySpot(matrix_game, 0, 0)[2];
		int j = emptySpot(matrix_game, 0, 2)[2];
		int k = emptySpot(matrix_game, 2, 0)[2];
		int l = emptySpot(matrix_game, 2, 2)[2];
		if (defendMoves(matrix_game)[0] == 1)
		{
			System.out.println("Computer's move was: " + (defendMoves(matrix_game)[1]+1) + " " + (defendMoves(matrix_game)[2]+1));
			matrix_game[defendMoves(matrix_game)[1]][defendMoves(matrix_game)[2]] = returnSign();
			
		}
		else 
		{
			if ((i==1) || (j==1) || (k==1) || (l==1))//until 4 corners are not occupied keep putting the O's in those 4 corners...
			{
				int comp_x = check4CornersEmpty(matrix_game)[0];
				int comp_y = check4CornersEmpty(matrix_game)[1];
				System.out.println("Computer's move was: " + (comp_x + 1) + " " + (comp_y+1));
				matrix_game[comp_x][comp_y] = returnSign();
			}
			else if ((emptySpot(matrix_game, 0, 0)[2] == 0) && ((emptySpot(matrix_game, 0, 2)[2] == 0) && (emptySpot(matrix_game, 1, 1)[2] == 0) 
					&& (emptySpot(matrix_game, 2, 0)[2] == 0) && ((emptySpot(matrix_game, 2, 2)[2] == 0) ) ))
			{
				int comp_x = check4DiamondSpots(matrix_game)[0];
				int comp_y = check4DiamondSpots(matrix_game)[1];
				System.out.println("Computer's move was: " + (comp_x + 1) + " " + (comp_y+1));
				matrix_game[comp_x][comp_y] = returnSign();
			}
		}
		
	}
	/**
	 * The leftDiagonalWin() method checks if there are three of the same values in the left diagonal
	 * and if there are then there is a winner
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param signXO is a string that represents the player's sign "X" or computer's sign "O"
	 * @return boolean value that tells if there is a winner in the left diagonal
	 */
	private boolean leftDiagonalWin(String[][] matrix_game, String signXO)
	{
		for (int left_counter = 0; left_counter < 3; ++left_counter)
		{
			if ((!matrix_game[left_counter][left_counter].equals(signXO)))
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * The rightDiagonalWin() method checks if there are three of the same values in the right diagonal
	 * and if there are then there is a winner
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param signXO is a string that represents the player's sign "X" or computer's sign "O"
	 * @return boolean value that tells if there is a winner in the right diagonal
	 */
	public boolean rightDiagonalWin(String[][] matrix_game, String signXO)
	{
		for (int inc_counter = 0, dec_counter = 2 ; inc_counter < 3 && dec_counter >= 0; ++inc_counter, --dec_counter)
		{
			if ((!matrix_game[inc_counter][dec_counter].equals(signXO)))
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * The horizontalWins() method checks if there are three of the same values in any one of the horizontal lanes
	 * and if there are then there is a winner
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param row is an integer that is the x coordinate of each horizontal lane
	 * @param signXO is a string that represents the player's sign "X" or computer's sign "O"
	 * @return boolean value that tells if there is a winner in any one of the horizontal lanes
	 */
	public boolean horizontalWins(String[][] matrix_game, int row, String signXO)
	{
		int counter = 0;
		for (int col = 0; col < 3; ++col)
		{
			if (matrix_game[row][col].equals(signXO))
			{
				++counter;
			}
		}
		
		if (counter != 3)
		{
			return false;
		}
		return true;	
	}
	
	/**
	 * The verticalWins() method checks if there are three of the same values in any one of the vertical lanes
	 * and if there are then there is a winner
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param col is an integer that is the y coordinate of each vertical lane
	 * @param signXO is a string that represents the player's sign "X" or computer's sign "O"
	 * @return boolean value that tells if there is a winner in any one of the vertical lanes
	 */
	public boolean verticalWins(String[][] matrix_game, int col, String signXO)
	{

		int counter = 0;
		for (int row = 0; row < 3; ++row)
		{
			if (matrix_game[row][col].equals(signXO))
			{
				++counter;
			}
		}
		
		if (counter != 3)
		{
			return false;
		}
		return true;	
	}
	
	/**
	 * The validFirstMoveInput() method checks if the player specified either 0 or 1 to tell
	 * if he/she wants to start the game or let the computer start the game.
	 * @param s represents the user input 
	 * @return integer that represents the value that the user entered if it is valid
	 */
	public int validFirstMoveInput(Scanner s)
	{
		int value;
		while (true)
		{
			if ((s.hasNextInt()))   //checks if the input is an integer
			{
				value = s.nextInt();
				if ((value != 1) && (value != 0))
				{
					System.out.print("Error: You must enter 0 or 1! Try again: \n");
					continue;
				}
				break;
			}
			else 
			{
				System.out.print("Error: You must enter 0 or 1! Try again: \n");
				s.next();
				continue;
			}
		}
			return value;
		
	}
	
	/**
	 * The validInput() method checks if the player specified either 1 or 2 or 3 to tell which
	 * row and column it wants to drop an "X" at in the matrix
	 * @param s represents the user input 
	 * @return integer that represents the value that the user entered if it is valid
	 */
	public int validInput(Scanner s)
	{
		int value;
		while (true)
		{
			if ((s.hasNextInt()))   //checks if the input is an integer
			{
				value = s.nextInt();
				if ((value != 1) && (value != 2) && (value != 3))
				{
					System.out.print("Error: You must enter 1, 2, or 3! Try again: \n");
					continue;
				}
				break;
			}
			else 
			{
				System.out.print("Error: You must enter 1, 2, or 3! Try again: \n");
				s.next();
				continue;
			}
		}
			return value;
	}
	
	/**
	 * The checkingWinningState() method calls the 4 private winning methods above to determine if 
	 * if there is a winner or a tie in those 8 directions in the matrix and 
	 * prints the winner and terminates the program
	 * @param matrix_game is a 2D array of strings that is the matrix
	 * @param signXO is a string that represents the player's sign "X" or computer's sign "O"
	 */
	public void checkingWinningState(String[][] matrix_game, String signXO)
	{
		//here check if its the winning move...8 possible winning ways
		if (leftDiagonalWin(matrix_game, signXO) || (rightDiagonalWin(matrix_game, signXO)))
		{
			System.out.println(signXO + " WON!");
			System.exit(0);
		}
		
		else if (horizontalWins(matrix_game, 0, signXO) || horizontalWins(matrix_game, 1,signXO) || horizontalWins(matrix_game, 2, signXO))
		{
			System.out.println(signXO + " WON!");
			System.exit(0);
		}
		
		else if (verticalWins(matrix_game, 0, signXO) || verticalWins(matrix_game, 1,signXO) || verticalWins(matrix_game, 2,signXO))
		{
			System.out.println( signXO + " WON!");
			System.exit(0);
		}
		else if (isBoardFull(matrix_game))
		{
			System.out.println("TIE");
			System.exit(0);
		}
		
	}
	
	/**
	 * The beginGame() method begins the game by asking the user which row and column he/she
	 * would like to place in the matrix/board and the game goes back and forth between
	 * the player and computer. It calls printBoard() to print the board after every move
	 * and prints the winner.
	 * @param matrix_game is a 2D array of strings that is the matrix
	 */
	public void beginGame(String[][] matrix_game)
	{
			Scanner s = new Scanner(System.in);			
			while (true)
			{
				if (turn == player_turn)
				{
					System.out.print("\t \t PLAYER'S TURN \n");
					System.out.print("Which row would you like to place the piece?[1,2,3] \n");
					int row_input = validInput(s);
					
					System.out.print("Which column would you like to place the piece? [1,2,3] \n");
					int col_input = validInput(s);
					
					if (validRowCol(matrix_game, row_input, col_input))
					{
						matrix_game[row_input-1][col_input-1] = returnSign();
						printBoard(matrix_game);
						turn = computer_turn;
						checkingWinningState(matrix_game, "X");
						++player_counter;
					}
					else
					{
						System.out.println("Invalid row and col!");
					}
				}
				else
				{
					//smart computer moves.....
					computerPlays(matrix_game);
					turn = player_turn;
					checkingWinningState(matrix_game, "O");
				}
			}		
	}
	
	/**
	 * The main() method calls the methods in the class TicTacToe() and tests its methods.
	 * @param args none
	 */
	public static void main(String args[])
	{
		String[][] matrix_game = new String[3][3];
		TicTacToe t = new TicTacToe(matrix_game);
		System.out.println("Welcome to the game of Tic Tac Toe.....\n");
		t.printBoard(matrix_game);
		t.checkTurn();
		t.beginGame(matrix_game);
		
	}
}
